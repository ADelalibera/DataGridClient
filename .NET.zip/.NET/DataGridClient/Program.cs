﻿using System;
using System.Net.Http;
using System.Net.Sockets;
using System.Threading.Tasks;
using Google.Protobuf;
using Google.Protobuf.WellKnownTypes;

class Program
{
    static async Task Main(string[] args)
    {
        // Criar uma instância da classe gerada a partir do arquivo .proto
        Greeting greeting = new Greeting
        {
            Name = "Delalibera",
            Message = "Hello from ProtoBuf!"
        };

        // Serializar a mensagem para bytes
        byte[] data;
        using (MemoryStream stream = new MemoryStream())
        {
            greeting.WriteTo(stream);
            data = stream.ToArray();
        }

        await EnsureGreetingCacheExists();

        // Enviar a mensagem para o DataGrid da Red Hat
        await SendToDataGrid_First(data);
        await SendToDataGridUsingHotRod(greeting);

        Console.WriteLine("Mensagem enviada com sucesso!");
    }

    static async Task SendToDataGrid_First(byte[] data)
    {
        // Substitua a URL abaixo pela URL real do seu DataGrid na Red Hat
        string dataGridUrl = "http://127.0.0.1:11222";

        using (HttpClient client = new HttpClient())
        {
            ByteArrayContent content = new ByteArrayContent(data);

            // Defina os cabeçalhos conforme necessário
            content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

            // Envie a solicitação para o DataGrid
            HttpResponseMessage response = await client.PostAsync(dataGridUrl, content);

            // Verifique a resposta (status code, etc.)
            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Mensagem enviada com sucesso para o DataGrid!");
            }
            else
            {
                Console.WriteLine($"Erro ao enviar mensagem para o DataGrid. Status Code: {response.StatusCode}");
            }
        }
    }

    static async Task SendToDataGrid_Second(byte[] data)
    {
        string dataGridUrl = "http://127.0.0.1:11222/";

        using (HttpClient client = new HttpClient())
        {
            ByteArrayContent content = new ByteArrayContent(data);
            content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

            HttpResponseMessage response = await client.PostAsync(dataGridUrl, content);

            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine("Mensagem enviada com sucesso para o DataGrid!");
            }
            else
            {
                Console.WriteLine($"Erro ao enviar mensagem para o DataGrid. Status Code: {response.StatusCode}");

                // Exiba a resposta do servidor em caso de erro
                string responseContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"Resposta do servidor: {responseContent}");
            }
        }
    }

    static async Task SendToDataGridUsingHotRod(Greeting greeting)
    {
        // Substitua essas informações pelas configurações do seu cluster HotRod
        string host = "127.0.0.1";
        int port = 11222;

        using (TcpClient tcpClient = new TcpClient(host, port))
        using (NetworkStream networkStream = tcpClient.GetStream())
        using (BinaryWriter writer = new BinaryWriter(networkStream))
        {
            // Cabeçalho de operação (Magic, Message ID, Op Code, etc.)
            // Consulte a documentação do protocolo HotRod para os detalhes
            // https://docs.jboss.org/infinispan/9.4/apidocs/org/infinispan/client/hotrod/impl/operations/OperationsFactory.html
            writer.Write(new byte[] { 0xA1, 0x9E, 0x04, 0x0 });
            writer.Write(1); // Message ID
            writer.Write(2); // Op Code (Put operation, por exemplo)

            // Seu código de serialização personalizado para o objeto Greeting
            // Substitua isso pelo seu código de serialização específico do HotRod
            byte[] serializedData;
            using (MemoryStream stream = new MemoryStream())
            {
                greeting.WriteTo(stream);
                serializedData = stream.ToArray();
            }

            // Dados da mensagem (neste exemplo, estamos apenas enviando os dados serializados do objeto Greeting)
            writer.Write(serializedData.Length);
            writer.Write(serializedData);

            // Envie os dados ao servidor HotRod
            writer.Flush();
        }
    }

    static async Task EnsureGreetingCacheExists()
    {
        // Substitua essas informações pelas configurações do seu cluster HotRod
        string host = "127.0.0.1";
        int port = 11222;

        // Nome do cache que você deseja criar ou verificar
        string cacheName = "GreetingCache";

        using (TcpClient tcpClient = new TcpClient(host, port))
        using (NetworkStream networkStream = tcpClient.GetStream())
        using (BinaryWriter writer = new BinaryWriter(networkStream))
        {
            // Cabeçalho de operação (Magic, Message ID, Op Code, etc.)
            writer.Write(new byte[] { 0xA1, 0x9E, 0x04, 0x0 });
            writer.Write(1); // Message ID
            writer.Write(7); // Op Code (Get or PutIfAbsent operation, por exemplo)

            // Nome do cache
            byte[] cacheNameBytes = System.Text.Encoding.UTF8.GetBytes(cacheName);
            writer.Write(cacheNameBytes.Length);
            writer.Write(cacheNameBytes);

            // Chave do cache (pode ser qualquer valor único)
            byte[] cacheKeyBytes = System.Text.Encoding.UTF8.GetBytes("GreetingKey");
            writer.Write(cacheKeyBytes.Length);
            writer.Write(cacheKeyBytes);

            // Se o cache não existir, crie-o
            Greeting greeting = new Greeting
            {
                Name = "Default",
                Message = "Welcome to the GreetingCache!"
            };

            byte[] serializedData;
            using (MemoryStream stream = new MemoryStream())
            {
                greeting.WriteTo(stream);
                serializedData = stream.ToArray();
            }

            // Dados da mensagem
            writer.Write(serializedData.Length);
            writer.Write(serializedData);

            // Envie os dados ao servidor HotRod
            writer.Flush();

            // Agora, você pode verificar se a operação foi bem-sucedida usando a resposta do servidor, se necessário
            // Consulte a documentação do protocolo HotRod para interpretar a resposta
        }
    }

}
